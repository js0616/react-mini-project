import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import {Badge} from 'react-bootstrap'
import { useSelector } from "react-redux";


const MovieCard = ({ movie }) => {


  // npm install --save react-spinners
  // npm install react-multi-carousel --save

  const {genresMovies} = useSelector((state) => state.movie); 

  // console.log(genresMovies)

  // let grn1= movie.genre_ids.map((ids)=>(
  //   genresMovies?.find((grn,idx)=>(grn.id == ids)
  // )).name
  
  // )

  // console.log('dd',grn1)
 
  const div_styled = {
    backgroundImage: `url(https://www.themoviedb.org/t/p/original${movie?.backdrop_path}`,
    width: "100%",
    height: "300px",
    backgroundSize: "cover",
  };

  return (
    <div style={div_styled} className="movie-card">
      <div className="overlay">
        <div>{movie.title}</div>
        {/* <div>{movie.genre_ids.map((ids)=>(
          <Badge bg="danger">{ids}</Badge>
        ))}</div> */}
        <div className="genres">{movie.genre_ids.map((ids, i)=>(
          <Badge bg="danger" key={i}>{genresMovies.find((grn,idx)=>(grn.id == ids)).name}</Badge>
        ))}</div>
      
        {/* <div className="genres">{movie.genre_ids.map((ids, i)=>(
          <Badge bg="danger" key={i}>{genresMovies.filter((grn,idx)=>(grn.id == ids))[0].name}</Badge>
        ))}</div> */}
        <div className="info">
          <span>평점 : {movie.vote_average}</span>
          <span>|</span>
          <span>{movie.adult? '청불':'청소년'}</span>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
